#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_PEGAWAI 100

// Upah per jam berdasarkan status pekerjaan
#define UPAH_CEO 210000
#define UPAH_MANAJER 130000
#define UPAH_KARYAWAN 80000
#define UPAH_OB 30000
#define UPAH_SATPAM 40000

// Bonus berdasarkan status pekerjaan
#define BONUS_CEO 100000
#define BONUS_MANAJER 45000
#define BONUS_KARYAWAN 200000
#define BONUS_OB 10000
#define BONUS_SATPAM 15000

// Konstanta tambahan
#define JAM_KERJA_MINIMAL 192
#define POTONGAN 0.05

void judul() {
    printf("===============================================\n");
    printf("        Program Menghitung Gaji Pegawai       |\n");
    printf("______________________________________________|\n");
    printf("Nama    : Muhammad Athif Alfathan             |\n");
    printf("NIM     : 24343097                            |\n");
    printf("===============================================\n");
}

typedef struct {
    char nama[50];
    int jamKerja;
    char status[20]; // Menggunakan array karakter untuk status pekerjaan
    float bonus;
    float totalGaji;
    float potonganGaji;
} Pegawai;

int validasiStatus(const char* status) {
    const char* statusValid[] = {"CEO", "Manajer", "Karyawan", "OB", "Satpam"};
    for (int i = 0; i < 5; i++) {
        if (strcmp(status, statusValid[i]) == 0) {
            return 1; // Status valid
        }
    }
    return 0; // Status tidak valid
}

float hitungUpahPerJam(const char* status) {
    if (strcmp(status, "CEO") == 0) {
        return UPAH_CEO;
    } else if (strcmp(status, "Manajer") == 0) {
        return UPAH_MANAJER;
    } else if (strcmp(status, "Karyawan") == 0) {
        return UPAH_KARYAWAN;
    } else if (strcmp(status, "OB") == 0) {
        return UPAH_OB;
    } else if (strcmp(status, "Satpam") == 0) {
        return UPAH_SATPAM;
    } else {
        return 0;
    }
}

float hitungBonus(const char* status, int jamKerja) {
    if (jamKerja < JAM_KERJA_MINIMAL) {
        return 0; // Tidak memenuhi jam kerja minimal, bonus 0
    }
    if (strcmp(status, "CEO") == 0) {
        return BONUS_CEO;
    } else if (strcmp(status, "Manajer") == 0) {
        return BONUS_MANAJER;
    } else if (strcmp(status, "Karyawan") == 0) {
        return BONUS_KARYAWAN;
    } else if (strcmp(status, "OB") == 0) {
        return BONUS_OB;
    } else if (strcmp(status, "Satpam") == 0) {
        return BONUS_SATPAM;
    } else {
        return 0;
    }
}

void hitungGaji(Pegawai *pegawai, int jumlah) {
    for (int i = 0; i < jumlah; i++) {
        float upahPerJam = hitungUpahPerJam(pegawai[i].status);
        pegawai[i].bonus = hitungBonus(pegawai[i].status, pegawai[i].jamKerja);

        if (pegawai[i].jamKerja <= 0) {
            pegawai[i].totalGaji = -1 * (upahPerJam + pegawai[i].bonus);
            pegawai[i].potonganGaji = 0;
        } else {
            if (pegawai[i].jamKerja > JAM_KERJA_MINIMAL) {
                float lembur = (pegawai[i].jamKerja - JAM_KERJA_MINIMAL) * upahPerJam * 0.25;
                pegawai[i].totalGaji = (pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus + lembur;
                pegawai[i].potonganGaji = 0;
            } else if (pegawai[i].jamKerja < JAM_KERJA_MINIMAL) {
                pegawai[i].potonganGaji = ((pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus) * POTONGAN;
                pegawai[i].totalGaji = (pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus - pegawai[i].potonganGaji;
            } else {
                pegawai[i].totalGaji = (pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus;
                pegawai[i].potonganGaji = 0;
            }
        }
    }
}

void tampilkanPegawai(Pegawai *pegawai, int jumlah) {
    printf("\nData Gaji Pegawai:\n");
    printf("============================================================================================================\n");
    printf("| No | Nama                 | Status    | Jam Kerja | Upah/Jam    | Bonus       | Potongan    | Total Gaji   |\n");
    printf("============================================================================================================\n");
    for (int i = 0; i < jumlah; i++) {
        printf("| %2d | %-20s | %-9s | %9d | Rp %-8.2f | Rp %-8.2f | Rp %-8.2f | Rp %.2f |\n", 
               i + 1, 
               pegawai[i].nama, 
               pegawai[i].status, 
               pegawai[i].jamKerja, 
               hitungUpahPerJam(pegawai[i].status), 
               pegawai[i].bonus, 
               pegawai[i].potonganGaji, 
               pegawai[i].totalGaji);
    }
    printf("============================================================================================================\n");
}

void simpanDataKeFile(Pegawai *pegawai, int jumlahPegawai) {
    FILE *outputFile = fopen("data_pegawai_output.txt", "w"); // Menggunakan mode "w" untuk menimpa data lama
    if (outputFile == NULL) {
        printf("Gagal membuka file untuk menyimpan data.\n");
        exit(1);
    }

    for (int i = 0; i < jumlahPegawai; i++) {
        fprintf(outputFile, "%s;%s;%d;%.2f;%.2f;%.2f\n", 
                pegawai[i].nama, 
                pegawai[i].status, 
                pegawai[i].jamKerja, 
                pegawai[i].bonus, 
                pegawai[i].potonganGaji, 
                pegawai[i].totalGaji);
    }

    fclose(outputFile);
    printf("Data pegawai berhasil disimpan ke data_pegawai_output.txt\n");
}

void bacaDataDariFile(Pegawai *pegawai, int *jumlahPegawai) {
    FILE *inputFile = fopen("data_pegawai_output.txt", "r");
    if (inputFile == NULL) {
        printf("File data pegawai tidak ditemukan.\n");
        return; // Jika file tidak ada, kita abaikan
    }

    while (fscanf(inputFile, "%49[^;];%19[^;];%d;%f;%f;%f\n", 
                  pegawai[*jumlahPegawai].nama, 
                  pegawai[*jumlahPegawai].status, 
                  &pegawai[*jumlahPegawai].jamKerja, 
                  &pegawai[*jumlahPegawai].bonus, 
                  &pegawai[*jumlahPegawai].potonganGaji, 
                  &pegawai[*jumlahPegawai].totalGaji) != EOF) {
        (*jumlahPegawai)++;
    }

    fclose(inputFile);
}

int main() {
    judul();
    Pegawai pegawai[MAX_PEGAWAI];
    int jumlahPegawai = 0;
    char continueInput;

    // Membaca data pegawai yang sudah ada
    bacaDataDariFile(pegawai, &jumlahPegawai);

    // Menampilkan data yang sudah ada
    if (jumlahPegawai > 0) {
        printf("\nData pegawai yang sudah ada:\n");
        tampilkanPegawai(pegawai, jumlahPegawai);
    } else {
        printf("\nTidak ada data pegawai sebelumnya.\n");
    }

    do {
        printf("\nMasukkan jumlah pegawai yang baru: ");
        int jumlahBaru;
        scanf("%d", &jumlahBaru);
        getchar(); // Mengkonsumsi newline

        for (int i = jumlahPegawai; i < jumlahPegawai + jumlahBaru; i++) {
            printf("\nData Pegawai %d:\n", i + 1);
            printf("Nama: ");
            fgets(pegawai[i].nama, 50, stdin);
            // Menghapus newline di akhir input nama
            size_t len = strlen(pegawai[i].nama);
            if (len > 0 && pegawai[i].nama[len - 1] == '\n') {
                pegawai[i].nama[len - 1] = '\0';
            }

            do {
                printf("Jam Kerja: ");
                scanf("%d", &pegawai[i].jamKerja);
                if (pegawai[i].jamKerja < 0 || pegawai[i].jamKerja > 300) {
                    printf("Jam kerja tidak valid. Masukkan antara 0 hingga 300.\n");
                }
            } while (pegawai[i].jamKerja < 0 || pegawai[i].jamKerja > 300);
            getchar(); // Mengkonsumsi newline

            do {
                printf("Status (CEO, Manajer, Karyawan, OB, Satpam): ");
                fgets(pegawai[i].status, 20, stdin);
                len = strlen(pegawai[i].status);
                if (len > 0 && pegawai[i].status[len - 1] == '\n') {
                    pegawai[i].status[len - 1] = '\0';
                }

                if (!validasiStatus(pegawai[i].status)) {
                    printf("Status tidak valid. Silakan masukkan kembali.\n");
                }
            } while (!validasiStatus(pegawai[i].status));
        }

        // Menghitung gaji pegawai
        hitungGaji(pegawai, jumlahPegawai + jumlahBaru);

        // Menampilkan data pegawai yang sudah ada + yang baru
        tampilkanPegawai(pegawai, jumlahPegawai + jumlahBaru);

        // Memperbarui jumlah pegawai
        jumlahPegawai += jumlahBaru;

        printf("\nApakah Anda ingin memasukkan data pegawai lain? (y/n): ");
        scanf(" %c", &continueInput); // Menambahkan spasi agar `\n` tidak terbaca
    } while (continueInput == 'y' || continueInput == 'Y');

    // Menyimpan data ke file setelah selesai
    simpanDataKeFile(pegawai, jumlahPegawai);

    printf("\nSemua data telah disimpan. Program selesai.\n");
    return 0;
}
