#include <stdio.h>
#include <string.h>

#define MAX_PEGAWAI 100

// Upah per jam berdasarkan status pekerjaan
#define UPAH_CEO 210000
#define UPAH_MANAJER 130000
#define UPAH_KARYAWAN 80000
#define UPAH_OB 30000
#define UPAH_SATPAM 40000

// Bonus berdasarkan status pekerjaan
#define BONUS_CEO 100000
#define BONUS_MANAJER 45000
#define BONUS_KARYAWAN 20000
#define BONUS_OB 10000
#define BONUS_SATPAM 15000

// Konstanta tambahan
#define JAM_KERJA_MINIMAL 192
#define POTONGAN 0.05

void judul() {
    printf("===============================================\n");
    printf("        Program Menghitung Gaji Pegawai       |\n");
    printf("______________________________________________|\n");
    printf("Nama    : Muhammad Athif Alfathan             |\n");
    printf("NIM     : 24343097                            |\n");
    printf("===============================================\n");
}

typedef struct {
    char nama[50];
    int jamKerja;
    char status[20]; // Menggunakan array karakter untuk status pekerjaan
    float bonus;
    float totalGaji;
    float potonganGaji;
} Pegawai;

float hitungUpahPerJam(const char* status) {
    if (strcmp(status, "CEO") == 0) {
        return UPAH_CEO;
    } else if (strcmp(status, "Manajer") == 0) {
        return UPAH_MANAJER;
    } else if (strcmp(status, "Karyawan") == 0) {
        return UPAH_KARYAWAN;
    } else if (strcmp(status, "OB") == 0) {
        return UPAH_OB;
    } else if (strcmp(status, "Satpam") == 0) {
        return UPAH_SATPAM;
    } else {
        return 0;
    }
}

float hitungBonus(const char* status, int jamKerja) {
    if (jamKerja < JAM_KERJA_MINIMAL) {
        return 0; // Tidak memenuhi jam kerja minimal, bonus 0
    }
    if (strcmp(status, "CEO") == 0) {
        return BONUS_CEO;
    } else if (strcmp(status, "Manajer") == 0) {
        return BONUS_MANAJER;
    } else if (strcmp(status, "Karyawan") == 0) {
        return BONUS_KARYAWAN;
    } else if (strcmp(status, "OB") == 0) {
        return BONUS_OB;
    } else if (strcmp(status, "Satpam") == 0) {
        return BONUS_SATPAM;
    } else {
        return 0;
    }
}

void hitungGaji(Pegawai *pegawai, int jumlah) {
    for (int i = 0; i < jumlah; i++) {
        float upahPerJam = hitungUpahPerJam(pegawai[i].status);
        pegawai[i].bonus = hitungBonus(pegawai[i].status, pegawai[i].jamKerja);

        if (pegawai[i].jamKerja <= 0) {
            pegawai[i].totalGaji = -1 * (upahPerJam + pegawai[i].bonus);
            pegawai[i].potonganGaji = 0;
        } else {
            if (pegawai[i].jamKerja > JAM_KERJA_MINIMAL) {
                float lembur = (pegawai[i].jamKerja - JAM_KERJA_MINIMAL) * upahPerJam * 0.25;
                pegawai[i].totalGaji = (pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus + lembur;
                pegawai[i].potonganGaji = 0;
            } else if (pegawai[i].jamKerja < JAM_KERJA_MINIMAL) {
                pegawai[i].potonganGaji = ((pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus) * POTONGAN;
                pegawai[i].totalGaji = (pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus - pegawai[i].potonganGaji;
            } else {
                pegawai[i].totalGaji = (pegawai[i].jamKerja * upahPerJam) + pegawai[i].bonus;
                pegawai[i].potonganGaji = 0;
            }
        }
    }
}

void tampilkanPegawai(Pegawai *pegawai, int jumlah) {
    printf("\nData Gaji Pegawai:\n");
    printf("=============================================================================================================\n");
    printf("| No | Nama                 | Status    | Jam Kerja | Upah/Jam    | Bonus       | Potongan    | Total Gaji   |\n");
    printf("============================================================================================================\n");
    for (int i = 0; i < jumlah; i++) {
        printf("| %2d | %-20s | %-9s | %9d | Rp %-8.2f | Rp %-8.2f | Rp %-8.2f | Rp %.2f |\n", 
               i + 1, 
               pegawai[i].nama, 
               pegawai[i].status, 
               pegawai[i].jamKerja, 
               hitungUpahPerJam(pegawai[i].status), 
               pegawai[i].bonus, 
               pegawai[i].potonganGaji, 
               pegawai[i].totalGaji);
    }
    printf("============================================================================================================\n");
}

int main() {
    judul();
    Pegawai pegawai[MAX_PEGAWAI];
    int jumlahPegawai;

    printf("Masukkan jumlah pegawai: ");
    scanf("%d", &jumlahPegawai);
    getchar();

    for (int i = 0; i < jumlahPegawai; i++) {
        printf("\nData Pegawai %d:\n", i + 1);
        printf("Nama: ");
        fgets(pegawai[i].nama, 50, stdin);
        // Menghapus newline di akhir input nama
        size_t len = strlen(pegawai[i].nama);
        if (len > 0 && pegawai[i].nama[len - 1] == '\n') {
            pegawai[i].nama[len - 1] = '\0';
        }
        printf("Jam Kerja: ");
        scanf("%d", &pegawai[i].jamKerja);
        getchar();
        printf("Status (CEO, Manajer, Karyawan, OB, Satpam): ");
        fgets(pegawai[i].status, 20, stdin);
        len = strlen(pegawai[i].status);
        if (len > 0 && pegawai[i].status[len - 1] == '\n') {
            pegawai[i].status[len - 1] = '\0';
        }
    }

    // Menghitung gaji pegawai
    hitungGaji(pegawai, jumlahPegawai);

    // Menampilkan data pegawai
    tampilkanPegawai(pegawai, jumlahPegawai);

    return 0;
}
