#include <stdio.h>

int main() {
    // Deklarasi variabel untuk informasi tambahan
    char nama[] = "Muhammad athif alfathan";
    char nim[] = "24343097";
    char tugas[] = "Menampilkan Elemen Array";

    // Deklarasi dan inisialisasi array
    int angka[5] = {10, 20, 30, 40, 50};

    // Menampilkan informasi tugas
    printf("Nama: %s\n", nama);
    printf("NIM: %s\n", nim);
    printf("Tugas: %s\n\n", tugas);

    // Menampilkan elemen-elemen array menggunakan loop
    printf("Elemen-elemen array angka:\n");
    for (int i = 0; i < 5; i++) {
        printf("angka[%d] = %d\n", i, angka[i]);
    }

    return 0;
}
