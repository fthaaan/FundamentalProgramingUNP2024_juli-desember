#include <stdio.h>
#include <string.h>

// Deklarasi fungsi bandingkanString
int bandingkanString(char str1[], char str2[]) {
    return strcmp(str1, str2);
}

int main() {
    char string1[100], string2[100];  // Mendeklarasikan array karakter untuk menyimpan dua input string

    // Menampilkan informasi Nama, NIM, dan Nama Tugas
    printf("Nama       : Muhammad Athif Alfahan\n");
    printf("NIM        : 24343097\n");
    printf("Nama Tugas : Membandingkan Dua String\n\n");

    // Meminta input dari pengguna
    printf("Masukkan string pertama: ");
    fgets(string1, sizeof(string1), stdin);
    string1[strcspn(string1, "\n")] = '\0';  // Menghapus karakter newline di akhir string1

    printf("Masukkan string kedua: ");
    fgets(string2, sizeof(string2), stdin);
    string2[strcspn(string2, "\n")] = '\0';  // Menghapus karakter newline di akhir string2

    // Memanggil fungsi bandingkanString dan menyimpan hasilnya
    int hasilPerbandingan = bandingkanString(string1, string2);

    // Menampilkan hasil perbandingan
    if (hasilPerbandingan == 0) {
        printf("Hasil perbandingan: String sama\n");
    } else {
        printf("Hasil perbandingan: String tidak sama\n");
    }

    return 0;
}
