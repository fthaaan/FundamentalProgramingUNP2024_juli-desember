#include <stdio.h>

int main() {
    // Deklarasi variabel untuk informasi tambahan
    char nama[] = "Muhammad Athif alfathan";
    char nim[] = "24343097";
    char tugas[] = "Mengganti Nilai Elemen Array";

    // Deklarasi dan inisialisasi array
    int angka[5] = {10, 20, 30, 40, 50};

    // Menampilkan informasi tugas
    printf("Nama: %s\n", nama);
    printf("NIM: %s\n", nim);
    printf("Tugas: %s\n\n", tugas);

    // Menampilkan array sebelum diganti
    printf("Array sebelum diganti:\n");
    for (int i = 0; i < 5; i++) {
        printf("angka[%d] = %d\n", i, angka[i]);
    }

    // Meminta pengguna untuk memasukkan indeks dan nilai baru
    int indeks;
    int nilaiBaru;
    printf("Masukkan nomor elemen yang ingin diganti (0-4): ");
    scanf("%d", &indeks);

    // Validasi input indeks
    if (indeks < 0 || indeks >= 5) {
        printf("Indeks tidak valid. Silakan masukkan indeks antara 0 dan 4.\n");
        return 1; // Menghentikan program dengan kode kesalahan
    }

    printf("Masukkan nilai baru: ");
    scanf("%d", &nilaiBaru);

    // Mengganti nilai pada indeks yang diminta
    angka[indeks] = nilaiBaru;

    // Menampilkan array setelah diganti
    printf("\nArray setelah diganti:\n");
    for (int i = 0; i < 5; i++) {
        printf("angka[%d] = %d\n", i, angka[i]);
    }

    return 0;
}
