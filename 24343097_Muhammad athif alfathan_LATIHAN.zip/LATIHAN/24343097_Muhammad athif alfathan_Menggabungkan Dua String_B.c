#include <stdio.h>
#include <string.h>

// Deklarasi fungsi gabungkanString
void gabungkanString(char str1[], char str2[], char hasil[]) {
    // Menyalin str1 ke dalam hasil
    strcpy(hasil, str1);
    // Menggabungkan str2 ke dalam hasil
    strcat(hasil, str2);
}

int main() {
    char string1[100], string2[100];  // Mendeklarasikan array karakter untuk menyimpan dua input string
    char hasilGabungan[200];          // Menyimpan hasil penggabungan string

    // Menampilkan informasi Nama, NIM, dan Nama Tugas
    printf("Nama       : Muhammad athif alfathan\n");
    printf("NIM        : 24343097\n");
    printf("Nama Tugas : Menggabungkan Dua String\n\n");

    // Meminta input dari pengguna
    printf("Masukkan string pertama: ");
    fgets(string1, sizeof(string1), stdin);
    string1[strcspn(string1, "\n")] = '\0';  // Menghapus karakter newline di akhir string1

    printf("Masukkan string kedua: ");
    fgets(string2, sizeof(string2), stdin);
    string2[strcspn(string2, "\n")] = '\0';  // Menghapus karakter newline di akhir string2

    // Memanggil fungsi gabungkanString
    gabungkanString(string1, string2, hasilGabungan);

    // Menampilkan hasil penggabungan
    printf("Hasil penggabungan: %s\n", hasilGabungan);

    return 0;
}
