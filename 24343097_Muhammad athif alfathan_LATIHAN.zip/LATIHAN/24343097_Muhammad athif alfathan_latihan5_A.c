#include <stdio.h>

// Deklarasi fungsi untuk menghitung luas persegi panjang
int hitungLuasPersegiPanjang(int panjang, int lebar) {
    return panjang * lebar;
}

int main() {

    printf("MODUL5.1_A.c \n");
    printf("=======================================\n");
    printf("Nama  : Muhammad athif alfathan \n");
    printf("NIM   : 24343097 \n");
    printf("Judul : Menghitung luas persegi panjang\n");
    printf("=======================================\n");
    printf("\n");

    int panjang, lebar, luas;

    // Memasukkan input
    printf("Masukkan panjang: ");
    scanf("%d", &panjang);
    printf("Masukkan lebar  : ");
    scanf("%d", &lebar);

    // Memanggil fungsi dan menampilkan hasil
    luas = hitungLuasPersegiPanjang(panjang, lebar);
    printf("Luas persegi panjang adalah: %d\n", luas);

    return 0;
}