#include <stdio.h>

int main() {
    // Deklarasi variabel untuk informasi tambahan
    char nama[] = "Muhammad athif alfathan";
    char nim[] = "24343097";
    char tugas[] = "Menjumlahkan Elemen Array";

    // Deklarasi dan inisialisasi array
    int angka[5] = {10, 20, 30, 40, 50};
    int total = 0; // Variabel untuk menyimpan total jumlah

    // Menampilkan informasi tugas
    printf("Nama: %s\n", nama);
    printf("NIM: %s\n", nim);
    printf("Tugas: %s\n\n", tugas);

    // Menghitung jumlah elemen array menggunakan loop
    for (int i = 0; i < 5; i++) {
        total += angka[i]; // Menjumlahkan setiap elemen
    }

    // Menampilkan hasil penjumlahan
    printf("Jumlah semua elemen array adalah: %d\n", total);

    return 0;
}
