#include <stdio.h>
#include <string.h>

// Deklarasi fungsi hitungPanjangString
int hitungPanjangString(char str[]) {
    return strlen(str);
}

int main() {
    char input[100];  // Mendeklarasikan array karakter untuk menyimpan input pengguna

    // Menampilkan informasi Nama, NIM, dan Nama Tugas
    printf("Nama       : Muhammad athif alfathan\n");
    printf("NIM        : 24343097\n");
    printf("Nama Tugas : Menghitung Panjang String\n\n");

    printf("Masukkan sebuah string: ");
    fgets(input, sizeof(input), stdin);  // Membaca input dari pengguna

    // Menghapus karakter newline yang ditambahkan oleh fgets
    input[strcspn(input, "\n")] = '\0';

    // Memanggil fungsi hitungPanjangString dan menyimpan hasilnya
    int panjang = hitungPanjangString(input);

    // Menampilkan panjang string
    printf("Panjang string yang dimasukkan: %d\n", panjang);

    return 0;
}
