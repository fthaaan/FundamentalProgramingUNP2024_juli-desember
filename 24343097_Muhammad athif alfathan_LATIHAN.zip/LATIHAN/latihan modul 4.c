#include <stdio.h>

#define MAX_PEGAWAI 100
#define UPAH_PER_JAM 5000
#define BONUS_HONORER 15000
#define BONUS_TETAP 20000
#define BONUS_HARIAN 0

typedef struct {
    char nama[50];
    int jamKerja;
    char status; // 'H' untuk honorer, 'T' untuk tetap
    float bonus;
    float totalGaji;
} Pegawai;

void hitungGaji(Pegawai *pegawai, int jumlah) {
    for (int i = 0; i < jumlah; i++) {
        if (pegawai[i].status == 'H' || pegawai[i].status == 'h') {
            pegawai[i].bonus = BONUS_HONORER;
        } else if (pegawai[i].status == 'T' || pegawai[i].status == 't') {
            pegawai[i].bonus = BONUS_TETAP;
        } else {
            pegawai[i].bonus = 0; // Jika status tidak valid, bonus diatur ke 0
        }
        pegawai[i].totalGaji = (pegawai[i].jamKerja * UPAH_PER_JAM) + pegawai[i].bonus;
    }
}

void tampilkanPegawai(Pegawai *pegawai, int jumlah) {
    printf("\nData Gaji Pegawai:\n");
    printf("------------------------------------------------------------------------------------------\n");
    printf("| No | Nama                | Status   | Jam Kerja | Upah/Jam | Bonus     | Total Gaji    |\n");
    printf("------------------------------------------------------------------------------------------\n");
    for (int i = 0; i < jumlah; i++) {
        printf("| %2d | %-20s | %-8s | %9d | Rp %-6.2f | Rp %-8.2f | Rp %.2f |\n", 
               i + 1, 
               pegawai[i].nama, 
               (pegawai[i].status == 'H' || pegawai[i].status == 'h') ? "Honorer" : "Tetap" , 
               pegawai[i].jamKerja, 
               (float)UPAH_PER_JAM, 
               pegawai[i].bonus, 
               pegawai[i].totalGaji);
    }
    printf("------------------------------------------------------------------------------------------\n");
}

int main() {
    Pegawai pegawai[MAX_PEGAWAI];
    int jumlahPegawai;

    printf("Masukkan jumlah pegawai: ");
    scanf("%d", &jumlahPegawai);
    getchar();

    for (int i = 0; i < jumlahPegawai; i++) {
        printf("\nData Pegawai %d:\n", i + 1);
        printf("Nama: ");
        fgets(pegawai[i].nama, 50, stdin);
        // Menghapus newline di akhir input nama
        size_t len = strlen(pegawai[i].nama);
        if (len > 0 && pegawai[i].nama[len - 1] == '\n') {
            pegawai[i].nama[len - 1] = '\0';
        }
        printf("Jam Kerja: ");
        scanf("%d", &pegawai[i].jamKerja);
        getchar();
        printf("Status (H untuk honorer, T untuk tetap): ");
        scanf("%c", &pegawai[i].status);
        getchar();
    }

    // Menghitung gaji pegawai
    hitungGaji(pegawai, jumlahPegawai);

    // Menampilkan data pegawai
    tampilkanPegawai(pegawai, jumlahPegawai);

    return 0;
}
