#include <stdio.h>
int main() {
    // deklarasi variabel
    float NilaiTugas, NilaiUTS, NilaiUAS, NilaiAkhir;
    int lulus;

    // input nilai dari pengguna
    printf("masukkan Nilai tugas (0-100): ");
    scanf("%f", &NilaiTugas);
    printf("masukkan nilai UTS (0-100): ");
    scanf("%f", &NilaiUTS);
    printf("masukkan nilai UAS (0-100): ");
    scanf("%f", &NilaiUAS);

    // Hitung nilai akhir
    NilaiAkhir = (0.3 * NilaiTugas) + (0.3 * NilaiUTS) + (0.4 * NilaiUAS);

    // Tentukan apakah lulus atau tidak
    lulus = (NilaiAkhir >= 60) && (NilaiTugas >= 50);

    // Output hasil
    printf("\nNilai Akhir Anda: %.2f\n", NilaiAkhir);

    if (lulus) {
        printf("Selamat! anda lulus.\n");
    } else {
        printf("Maaf, anda tidak lulus.\n");
    }
    return 0;
}
