#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int angkaTebakan, tebakan, kesempatan, mainLagi, level;
    int skorTertinggi = 10001; // Inisialisasi dengan skor yang sangat tinggi
    int skorSekarang;
    char pilihan;

    // Menginisialisasi generator angka acak
    srand(time(0));

    do {
        // Memilih level kesulitan
        do {
            printf("Pilih level kesulitan:\n");
            printf("1. easy (1-100)\n");
            printf("2. medium (1-750)\n");
            printf("3. hard (1-3000)\n");
            printf("4. very hard (1-10000)\n");
            printf("Masukkan pilihan level 1-4: ");
            scanf("%d", &level);

            if (level < 1 || level > 4) {
                printf("Pilihan tidak valid. Silakan coba lagi.\n");
            }
        } while (level < 1 || level > 4); // Memastikan level yang valid

        switch (level) {
            case 1:
                angkaTebakan = rand() % 100 + 1;
                kesempatan = 10;
                printf("Anda memilih level easy. Tebak angka antara 1 dan 100.\n");
                break;
            case 2:
                angkaTebakan = rand() % 750 + 1;
                kesempatan = 20;
                printf("Anda memilih level medium. Tebak angka antara 1 dan 750.\n");
                break;
            case 3:
                angkaTebakan = rand() % 3000 + 1;
                kesempatan = 25;
                printf("Anda memilih level hard. Tebak angka antara 1 dan 3000.\n");
                break;
            case 4:
                angkaTebakan = rand() % 10000 + 1;
                kesempatan = 30;
                printf("Anda memilih level very hard. Tebak angka antara 1 dan 10000.\n");
                break;
        }

        skorSekarang = 0;
        printf("Anda memiliki %d kesempatan untuk menebaknya.\n", kesempatan);

        // Mulai permainan
        while (kesempatan > 0) {
            printf("\nMasukkan tebakan Anda: ");
            scanf("%d", &tebakan);
            skorSekarang++;

            if (tebakan > angkaTebakan) {
                printf("Tebakan Anda terlalu tinggi!\n");
            } else if (tebakan < angkaTebakan) {
                printf("Tebakan Anda terlalu rendah!\n");
            } else {
                printf("Selamat! Anda menebak dengan benar!\n");
                if (skorSekarang < skorTertinggi) {
                    skorTertinggi = skorSekarang;
                    printf("Skor baru tercapai dengan %d tebakan! Ini adalah skor tertinggi baru!\n", skorTertinggi);
                } else {
                    printf("Anda menebak dengan %d tebakan.\n", skorSekarang);
                }
                break;
            }

            kesempatan--;
            printf("Kesempatan tersisa: %d\n", kesempatan);
        }

        // Jika kesempatan habis dan belum menebak dengan benar
        if (kesempatan == 0) {
            printf("Maaf, Anda kehabisan kesempatan. Angka yang benar adalah %d.\n", angkaTebakan);
        }

        // Menampilkan skor tertinggi
        printf("Skor tertinggi Anda adalah: %d tebakan.\n", skorTertinggi);

        // Opsi untuk bermain lagi
        printf("Apakah Anda ingin bermain lagi? (y/n): ");
        scanf(" %c", &pilihan); // Pastikan ada spasi sebelum %c

        switch (pilihan) {
            case 'y':
            case 'Y':
                mainLagi = 1;
                break;
            case 'n':
            case 'N':
                mainLagi = 0;
                printf("Terima kasih telah bermain!\n");
                break;
            default:
                printf("Pilihan tidak valid, keluar dari permainan.\n");
                mainLagi = 0;
                break;
        }

    } while (mainLagi);

    return 0;
}
