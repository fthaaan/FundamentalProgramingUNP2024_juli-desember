#include <stdio.h>

// Fungsi rekursif untuk memecahkan masalah Menara Hanoi
void hanoi(int n, char source, char target, char auxiliary, int *count) {
    if (n == 1) {
        printf("Pindahkan cakram 1 dari tiang %c ke tiang %c\n", source, target);
        (*count)++;
    } else {
        // Pindahkan n-1 cakram dari sumber ke tiang bantu
        hanoi(n - 1, source, auxiliary, target, count);

        // Pindahkan cakram terbesar ke tiang tujuan
        printf("Pindahkan cakram %d dari tiang %c ke tiang %c\n", n, source, target);
        (*count)++;

        // Pindahkan n-1 cakram dari tiang bantu ke tiang tujuan
        hanoi(n - 1, auxiliary, target, source, count);
    }
}

int main() {
    printf("=========================================\n");
    printf("nama    : muhammad athif alfathan \n");
    printf("nim     : 24343097                \n");
    printf("latihan : Tugas permainan hanoi   \n");
    printf("=========================================\n");
    int num_disks, count = 0;

    // Meminta input jumlah cakram dari pengguna
    printf("Masukkan jumlah cakram: ");
    scanf("%d", &num_disks);

    // Memanggil fungsi Menara Hanoi
    hanoi(num_disks, 'A', 'C', 'B', &count);

    // Menampilkan total langkah yang diperlukan
    printf("Jumlah total langkah: %d\n", count);

    return 0;
}
